﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
namespace my_larvel
{
    public partial class Form1 : MetroFramework.Forms.MetroForm
    {   
        private static StringBuilder cmdOutput = null;
        Process cmdProcess;
        StreamWriter cmdStreamWriter;
        public string jurl;
            public Form1()
        {
            InitializeComponent();
        }
        public void Progr1()
        {
            for (int index = 0; index <= 100; ++index)
                this.progressBar1.Value = index;
        }

        public void Progrbar()
        {
           for (int index = 100; index <= 0; --index)
                this.progressBar1.Value = index;
        }
        public void urlinpout(){
          using (StreamReader readtext = new StreamReader("jurl.txt"))
             {

                 string readMeText = readtext.ReadLine();
                 textBox2.Text = readMeText.ToString();
             }

         }


        public void urloutput()
        {
            using (StreamReader readtext = new StreamReader("jurl.txt"))
            {

                string readMeText = readtext.ReadLine();
                textBox2.Text = readMeText.ToString();
            }

        }


        //--------goode programe --------
        public void cmd()
        {
            cmdOutput = new StringBuilder("");
            cmdProcess = new Process();

            cmdProcess.StartInfo.FileName = "cmd.exe";
            cmdProcess.StartInfo.UseShellExecute = false;
            cmdProcess.StartInfo.CreateNoWindow = true;
            cmdProcess.StartInfo.RedirectStandardOutput = true;

            string ja = @"/K cd " + textBox2.Text;
            cmdProcess.StartInfo.Arguments = ja;




            cmdProcess.OutputDataReceived += new DataReceivedEventHandler(SortOutputHandler);
            cmdProcess.StartInfo.RedirectStandardInput = true;
            cmdProcess.Start();

            cmdStreamWriter = cmdProcess.StandardInput;
            cmdProcess.BeginOutputReadLine();

        }




        private void Form1_Load(object sender, EventArgs e)
        {
            //--------------function for  inpot ----- 
            urlinpout();
            //--------------function for  inpot ----- 

            cmd();
            

        }

         private static void SortOutputHandler(object sendingProcess,DataReceivedEventArgs outLine)
        {
            if (!String.IsNullOrEmpty(outLine.Data))
            {
                cmdOutput.Append(Environment.NewLine + outLine.Data);
            }
        }

         private void button1_Click(object sender, EventArgs e)
         {

      //-------------------------------------------------------------------------------------------
             cmd();
     //---------------------------------------------------------------------------------------
             this.Progrbar();
             cmdStreamWriter.WriteLine(textBox1.Text);
             richTextBox1.Text = cmdOutput.ToString();
    //-------------------------------------------------------------------------------------------------
             Progr1();
   //----------------------------------------------------------------------------------
         }

         private void button2_Click(object sender, EventArgs e)
         {
             this.Progrbar();
             richTextBox1.Text = cmdOutput.ToString();
             Progr1();
         }

         private void timer1_Tick(object sender, EventArgs e)
         {
             richTextBox1.Text = cmdOutput.ToString();
         
         }

         private void button3_Click(object sender, EventArgs e)
         {
             this.Progrbar();
             cmdStreamWriter.Close();
             cmdProcess.WaitForExit(); 
             cmdProcess.Close();
             richTextBox1.Text = "";
             Progr1();
             
         }

         private void button4_Click(object sender, EventArgs e)
         {

             this.Progrbar();
            


             FolderBrowserDialog fbd = new FolderBrowserDialog();
             if (fbd.ShowDialog() == DialogResult.OK)
             {

          
                 string[] files = Directory.GetFiles(fbd.SelectedPath);
                 string[] dire = Directory.GetDirectories(fbd.SelectedPath);

                  textBox2.Text = fbd.SelectedPath;

                
             }
           

             Progr1();
         }

         private void textBox2_TextChanged(object sender, EventArgs e)
         {
            
         }

        

         private void checkBox1_CheckedChanged(object sender, EventArgs e)
         {
             if (checkBox1.Checked == true)
             {
                 textBox1.Text = "";
                 textBox1.Text = "composer global require laravel/installer";




             }
             else
             {
                 textBox1.Text = "";
                 MessageBox.Show("First, download the Laravel installer using Composer:");
             }
         }

         private void textBox3_TextChanged(object sender, EventArgs e)
         {
             
         }

         private void checkBox2_CheckedChanged(object sender, EventArgs e)
         {
             if (textBox3.Text != "") {

                 textBox1.Text = "";
                 textBox1.Text = "composer create-project --prefer-dist laravel/laravel " + " " + textBox3.Text;

             }
             else
             {
                 MessageBox.Show("plz your box");
                 checkBox1.Checked = false;
                 checkBox3.Checked = false;
                 checkBox2.Checked = false;
                 textBox4.Text = "";

             }

         }

         private void checkBox3_CheckedChanged(object sender, EventArgs e)
         {
             if (textBox4.Text != "")
             {

                 textBox1.Text = "";
                 textBox1.Text = "laravel new " + " " + textBox4.Text;

             }
             else
             {
                 MessageBox.Show("plz your box");
                 checkBox1.Checked = false;
                 checkBox2.Checked = false;
                 textBox3.Text = "";
                 checkBox3.Checked = false;
                 
             }
         }

         private void button5_Click(object sender, EventArgs e)
         {
            

             if (textBox2.Text == "")
             {
                 MessageBox.Show("get url for your project");
                 button1.Enabled = false;
                 button2.Enabled = false;
                 button3.Enabled = false;

             }
             else
             {
             
                 jurl =textBox2.Text;
                 button1.Enabled = true;
                 button2.Enabled = true;
                 button3.Enabled = true;
                 textBox2.Text = jurl;

                 urloutput();
                
             }
         }

         private void checkBox4_CheckedChanged(object sender, EventArgs e)
         {
              if (checkBox4.Checked==true) {

                 textBox1.Text = "";
                 textBox1.Text = "php artisan serve";

             }
              
         }

         private void checkBox5_CheckedChanged(object sender, EventArgs e)
         {
             if (checkBox5.Checked == true)
             {

                 textBox1.Text = "";
                 textBox1.Text = "php artisan serve --port=" + comboBox1.Text;

             }
         }

         private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
         {
             comboBox1.Text = "8080";
         }

         private void checkBox6_CheckedChanged(object sender, EventArgs e)
         {
             if (checkBox6.Checked == true && comboBox2.Text !="")
             {

                 textBox1.Text = "";
                 textBox5.Text = "127.0.0.1";
                 textBox1.Text = "php artisan serve --host=" + textBox5.Text + "--port=" + comboBox2.Text;

             }
             else
             {

                 MessageBox.Show("create un host and port");
             }

         }

         private void checkBox8_CheckedChanged(object sender, EventArgs e)
         {
             
                  if (checkBox8.Checked == true)
             {

                 textBox1.Text = "";
                 textBox1.Text = "php artisan make:controller " + textBox6.Text;

             }


         }

         private void button6_Click(object sender, EventArgs e)
         {
            
         }

         private void button6_Click_1(object sender, EventArgs e)
         {

         }

         private void checkBox9_CheckedChanged(object sender, EventArgs e)
         {
             if (checkBox9.Checked == true)
             {

                 textBox1.Text = "";
                 textBox1.Text = "php artisan make:model" + textBox7.Text;

             }
         }

         private void textBox8_TextChanged(object sender, EventArgs e)
         {
            

                 if (checkBox8.Checked == true)
             {

                 textBox1.Text = "";
                 textBox1.Text = " php artisan make:migration" + textBox8.Text;

             }
         }

         private void textBox1_TextChanged(object sender, EventArgs e)
         {

         }

         private void checkBox10_CheckedChanged(object sender, EventArgs e)
         {

         }

         private void label3_Click(object sender, EventArgs e)
         {

         }

         private void checkBox15_CheckedChanged(object sender, EventArgs e)
         {

         }

         private void radioButton1_CheckedChanged(object sender, EventArgs e)
         {
            

                    if (radioButton1.Checked == true)
             {

                 textBox1.Text = "";
                 textBox1.Text = "  php artisan help";

             }

         }
         


    }
}
